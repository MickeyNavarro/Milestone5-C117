﻿namespace Milestone4_5
{
    partial class ClothesInventory1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tab_home = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tab_add = new System.Windows.Forms.TabPage();
            this.textBox_quantity = new System.Windows.Forms.TextBox();
            this.label_quantity = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox_mark = new System.Windows.Forms.ComboBox();
            this.comboBox_type = new System.Windows.Forms.ComboBox();
            this.comboBox_category = new System.Windows.Forms.ComboBox();
            this.button_add = new System.Windows.Forms.Button();
            this.textBox_comment = new System.Windows.Forms.TextBox();
            this.textBox_material = new System.Windows.Forms.TextBox();
            this.textBox_color = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tab_restock = new System.Windows.Forms.TabPage();
            this.textBox_restock_quantity = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button_restock = new System.Windows.Forms.Button();
            this.listBox_restock = new System.Windows.Forms.ListBox();
            this.tab_remove = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.button_remove = new System.Windows.Forms.Button();
            this.listBox_remove = new System.Windows.Forms.ListBox();
            this.tab_search = new System.Windows.Forms.TabPage();
            this.listBox_search = new System.Windows.Forms.ListBox();
            this.button_search = new System.Windows.Forms.Button();
            this.comboBox_cat_srch = new System.Windows.Forms.ComboBox();
            this.textBox_col_srch = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.process1 = new System.Diagnostics.Process();
            this.button_search_clear = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tab_home.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tab_add.SuspendLayout();
            this.tab_restock.SuspendLayout();
            this.tab_remove.SuspendLayout();
            this.tab_search.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tab_home);
            this.tabControl1.Controls.Add(this.tab_add);
            this.tabControl1.Controls.Add(this.tab_restock);
            this.tabControl1.Controls.Add(this.tab_remove);
            this.tabControl1.Controls.Add(this.tab_search);
            this.tabControl1.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1109, 569);
            this.tabControl1.TabIndex = 0;
            // 
            // tab_home
            // 
            this.tab_home.Controls.Add(this.dataGridView1);
            this.tab_home.Controls.Add(this.listBox1);
            this.tab_home.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_home.Location = new System.Drawing.Point(4, 49);
            this.tab_home.Name = "tab_home";
            this.tab_home.Padding = new System.Windows.Forms.Padding(3);
            this.tab_home.Size = new System.Drawing.Size(1101, 516);
            this.tab_home.TabIndex = 1;
            this.tab_home.Text = "Home";
            this.tab_home.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Agency FB", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.MediumPurple;
            this.dataGridView1.Location = new System.Drawing.Point(-4, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1119, 528);
            this.dataGridView1.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 31;
            this.listBox1.Location = new System.Drawing.Point(0, 6);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(876, 376);
            this.listBox1.TabIndex = 0;
            // 
            // tab_add
            // 
            this.tab_add.BackColor = System.Drawing.Color.MediumPurple;
            this.tab_add.Controls.Add(this.textBox_quantity);
            this.tab_add.Controls.Add(this.label_quantity);
            this.tab_add.Controls.Add(this.label6);
            this.tab_add.Controls.Add(this.comboBox_mark);
            this.tab_add.Controls.Add(this.comboBox_type);
            this.tab_add.Controls.Add(this.comboBox_category);
            this.tab_add.Controls.Add(this.button_add);
            this.tab_add.Controls.Add(this.textBox_comment);
            this.tab_add.Controls.Add(this.textBox_material);
            this.tab_add.Controls.Add(this.textBox_color);
            this.tab_add.Controls.Add(this.label5);
            this.tab_add.Controls.Add(this.label4);
            this.tab_add.Controls.Add(this.label3);
            this.tab_add.Controls.Add(this.label2);
            this.tab_add.Controls.Add(this.label1);
            this.tab_add.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_add.ForeColor = System.Drawing.Color.White;
            this.tab_add.Location = new System.Drawing.Point(4, 49);
            this.tab_add.Name = "tab_add";
            this.tab_add.Padding = new System.Windows.Forms.Padding(3);
            this.tab_add.Size = new System.Drawing.Size(1101, 516);
            this.tab_add.TabIndex = 0;
            this.tab_add.Text = "Add";
            // 
            // textBox_quantity
            // 
            this.textBox_quantity.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_quantity.Location = new System.Drawing.Point(172, 192);
            this.textBox_quantity.Name = "textBox_quantity";
            this.textBox_quantity.Size = new System.Drawing.Size(900, 45);
            this.textBox_quantity.TabIndex = 16;
            // 
            // label_quantity
            // 
            this.label_quantity.AutoSize = true;
            this.label_quantity.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_quantity.ForeColor = System.Drawing.Color.White;
            this.label_quantity.Location = new System.Drawing.Point(64, 185);
            this.label_quantity.Name = "label_quantity";
            this.label_quantity.Size = new System.Drawing.Size(102, 40);
            this.label_quantity.TabIndex = 15;
            this.label_quantity.Text = "Quantity:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(38, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 40);
            this.label6.TabIndex = 14;
            this.label6.Text = "Comments:";
            // 
            // comboBox_mark
            // 
            this.comboBox_mark.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_mark.FormattingEnabled = true;
            this.comboBox_mark.Items.AddRange(new object[] {
            "Keep",
            "Donate",
            "Sell"});
            this.comboBox_mark.Location = new System.Drawing.Point(172, 282);
            this.comboBox_mark.Name = "comboBox_mark";
            this.comboBox_mark.Size = new System.Drawing.Size(900, 48);
            this.comboBox_mark.TabIndex = 13;
            // 
            // comboBox_type
            // 
            this.comboBox_type.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_type.FormattingEnabled = true;
            this.comboBox_type.Items.AddRange(new object[] {
            "Casual",
            "Formal",
            "School",
            "Work",
            "Costume",
            "Other"});
            this.comboBox_type.Location = new System.Drawing.Point(172, 54);
            this.comboBox_type.Name = "comboBox_type";
            this.comboBox_type.Size = new System.Drawing.Size(900, 48);
            this.comboBox_type.TabIndex = 12;
            // 
            // comboBox_category
            // 
            this.comboBox_category.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_category.FormattingEnabled = true;
            this.comboBox_category.Location = new System.Drawing.Point(172, 6);
            this.comboBox_category.Name = "comboBox_category";
            this.comboBox_category.Size = new System.Drawing.Size(900, 48);
            this.comboBox_category.TabIndex = 11;
            // 
            // button_add
            // 
            this.button_add.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_add.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button_add.Location = new System.Drawing.Point(971, 455);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(127, 56);
            this.button_add.TabIndex = 10;
            this.button_add.Text = "ADD";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // textBox_comment
            // 
            this.textBox_comment.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_comment.Location = new System.Drawing.Point(172, 237);
            this.textBox_comment.Name = "textBox_comment";
            this.textBox_comment.Size = new System.Drawing.Size(900, 45);
            this.textBox_comment.TabIndex = 9;
            // 
            // textBox_material
            // 
            this.textBox_material.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_material.Location = new System.Drawing.Point(172, 102);
            this.textBox_material.Name = "textBox_material";
            this.textBox_material.Size = new System.Drawing.Size(900, 45);
            this.textBox_material.TabIndex = 7;
            // 
            // textBox_color
            // 
            this.textBox_color.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_color.Location = new System.Drawing.Point(172, 147);
            this.textBox_color.Name = "textBox_color";
            this.textBox_color.Size = new System.Drawing.Size(900, 45);
            this.textBox_color.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(42, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 40);
            this.label5.TabIndex = 4;
            this.label5.Text = "Marked as:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(93, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 40);
            this.label4.TabIndex = 3;
            this.label4.Text = "Color:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(64, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 40);
            this.label3.TabIndex = 2;
            this.label3.Text = "Material:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(100, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 40);
            this.label2.TabIndex = 1;
            this.label2.Text = "Type:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(55, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "Category:";
            // 
            // tab_restock
            // 
            this.tab_restock.BackColor = System.Drawing.Color.MediumPurple;
            this.tab_restock.Controls.Add(this.textBox_restock_quantity);
            this.tab_restock.Controls.Add(this.label9);
            this.tab_restock.Controls.Add(this.label7);
            this.tab_restock.Controls.Add(this.button_restock);
            this.tab_restock.Controls.Add(this.listBox_restock);
            this.tab_restock.Location = new System.Drawing.Point(4, 49);
            this.tab_restock.Name = "tab_restock";
            this.tab_restock.Size = new System.Drawing.Size(1101, 516);
            this.tab_restock.TabIndex = 2;
            this.tab_restock.Text = "Restock";
            // 
            // textBox_restock_quantity
            // 
            this.textBox_restock_quantity.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_restock_quantity.Location = new System.Drawing.Point(793, 220);
            this.textBox_restock_quantity.Name = "textBox_restock_quantity";
            this.textBox_restock_quantity.Size = new System.Drawing.Size(225, 45);
            this.textBox_restock_quantity.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(794, 177);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(224, 40);
            this.label9.TabIndex = 5;
            this.label9.Text = "# to add to quantity: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(13, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(360, 40);
            this.label7.TabIndex = 4;
            this.label7.Text = "Choose a clothing item to restock: ";
            // 
            // button_restock
            // 
            this.button_restock.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_restock.Location = new System.Drawing.Point(945, 456);
            this.button_restock.Name = "button_restock";
            this.button_restock.Size = new System.Drawing.Size(149, 55);
            this.button_restock.TabIndex = 3;
            this.button_restock.Text = "RESTOCK";
            this.button_restock.UseVisualStyleBackColor = true;
            this.button_restock.Click += new System.EventHandler(this.button_restock_Click);
            // 
            // listBox_restock
            // 
            this.listBox_restock.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_restock.FormattingEnabled = true;
            this.listBox_restock.ItemHeight = 40;
            this.listBox_restock.Location = new System.Drawing.Point(20, 56);
            this.listBox_restock.Name = "listBox_restock";
            this.listBox_restock.Size = new System.Drawing.Size(726, 444);
            this.listBox_restock.TabIndex = 2;
            // 
            // tab_remove
            // 
            this.tab_remove.BackColor = System.Drawing.Color.MediumPurple;
            this.tab_remove.Controls.Add(this.label8);
            this.tab_remove.Controls.Add(this.button_remove);
            this.tab_remove.Controls.Add(this.listBox_remove);
            this.tab_remove.Location = new System.Drawing.Point(4, 49);
            this.tab_remove.Name = "tab_remove";
            this.tab_remove.Size = new System.Drawing.Size(1101, 516);
            this.tab_remove.TabIndex = 3;
            this.tab_remove.Text = "Remove";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(12, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(354, 40);
            this.label8.TabIndex = 5;
            this.label8.Text = "Choose a clothing item to remove:";
            // 
            // button_remove
            // 
            this.button_remove.Location = new System.Drawing.Point(945, 456);
            this.button_remove.Name = "button_remove";
            this.button_remove.Size = new System.Drawing.Size(149, 55);
            this.button_remove.TabIndex = 1;
            this.button_remove.Text = "REMOVE";
            this.button_remove.UseVisualStyleBackColor = true;
            this.button_remove.Click += new System.EventHandler(this.button_remove_Click);
            // 
            // listBox_remove
            // 
            this.listBox_remove.FormattingEnabled = true;
            this.listBox_remove.ItemHeight = 40;
            this.listBox_remove.Location = new System.Drawing.Point(19, 56);
            this.listBox_remove.Name = "listBox_remove";
            this.listBox_remove.Size = new System.Drawing.Size(724, 444);
            this.listBox_remove.TabIndex = 0;
            // 
            // tab_search
            // 
            this.tab_search.BackColor = System.Drawing.Color.MediumPurple;
            this.tab_search.Controls.Add(this.button_search_clear);
            this.tab_search.Controls.Add(this.listBox_search);
            this.tab_search.Controls.Add(this.button_search);
            this.tab_search.Controls.Add(this.comboBox_cat_srch);
            this.tab_search.Controls.Add(this.textBox_col_srch);
            this.tab_search.Controls.Add(this.label12);
            this.tab_search.Controls.Add(this.label14);
            this.tab_search.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_search.Location = new System.Drawing.Point(4, 49);
            this.tab_search.Name = "tab_search";
            this.tab_search.Padding = new System.Windows.Forms.Padding(3);
            this.tab_search.Size = new System.Drawing.Size(1101, 516);
            this.tab_search.TabIndex = 4;
            this.tab_search.Text = "Search";
            // 
            // listBox_search
            // 
            this.listBox_search.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_search.FormattingEnabled = true;
            this.listBox_search.ItemHeight = 40;
            this.listBox_search.Location = new System.Drawing.Point(345, 17);
            this.listBox_search.Name = "listBox_search";
            this.listBox_search.Size = new System.Drawing.Size(739, 484);
            this.listBox_search.TabIndex = 32;
            // 
            // button_search
            // 
            this.button_search.BackColor = System.Drawing.Color.White;
            this.button_search.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_search.Location = new System.Drawing.Point(186, 265);
            this.button_search.Name = "button_search";
            this.button_search.Size = new System.Drawing.Size(120, 51);
            this.button_search.TabIndex = 31;
            this.button_search.Text = "SEARCH";
            this.button_search.UseVisualStyleBackColor = false;
            this.button_search.Click += new System.EventHandler(this.button_search_Click);
            // 
            // comboBox_cat_srch
            // 
            this.comboBox_cat_srch.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_cat_srch.FormattingEnabled = true;
            this.comboBox_cat_srch.Location = new System.Drawing.Point(149, 166);
            this.comboBox_cat_srch.Name = "comboBox_cat_srch";
            this.comboBox_cat_srch.Size = new System.Drawing.Size(170, 48);
            this.comboBox_cat_srch.TabIndex = 28;
            // 
            // textBox_col_srch
            // 
            this.textBox_col_srch.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_col_srch.Location = new System.Drawing.Point(149, 214);
            this.textBox_col_srch.Name = "textBox_col_srch";
            this.textBox_col_srch.Size = new System.Drawing.Size(170, 45);
            this.textBox_col_srch.TabIndex = 27;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(70, 214);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 40);
            this.label12.TabIndex = 25;
            this.label12.Text = "Color:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(32, 169);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(111, 40);
            this.label14.TabIndex = 23;
            this.label14.Text = "Category:";
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // process1
            // 
            this.process1.StartInfo.Domain = "";
            this.process1.StartInfo.LoadUserProfile = false;
            this.process1.StartInfo.Password = null;
            this.process1.StartInfo.StandardErrorEncoding = null;
            this.process1.StartInfo.StandardOutputEncoding = null;
            this.process1.StartInfo.UserName = "";
            this.process1.SynchronizingObject = this;
            // 
            // button_search_clear
            // 
            this.button_search_clear.BackColor = System.Drawing.Color.White;
            this.button_search_clear.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_search_clear.Location = new System.Drawing.Point(60, 265);
            this.button_search_clear.Name = "button_search_clear";
            this.button_search_clear.Size = new System.Drawing.Size(120, 51);
            this.button_search_clear.TabIndex = 33;
            this.button_search_clear.Text = "CLEAR";
            this.button_search_clear.UseVisualStyleBackColor = false;
            this.button_search_clear.Click += new System.EventHandler(this.button_search_clear_Click);
            // 
            // ClothesInventory1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1122, 584);
            this.Controls.Add(this.tabControl1);
            this.Name = "ClothesInventory1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ClothesInventory1_FormClosing);
            this.tabControl1.ResumeLayout(false);
            this.tab_home.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tab_add.ResumeLayout(false);
            this.tab_add.PerformLayout();
            this.tab_restock.ResumeLayout(false);
            this.tab_restock.PerformLayout();
            this.tab_remove.ResumeLayout(false);
            this.tab_remove.PerformLayout();
            this.tab_search.ResumeLayout(false);
            this.tab_search.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_add;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.TextBox textBox_comment;
        private System.Windows.Forms.TextBox textBox_material;
        private System.Windows.Forms.TextBox textBox_color;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tab_home;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox_mark;
        private System.Windows.Forms.ComboBox comboBox_type;
        private System.Windows.Forms.ComboBox comboBox_category;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tab_restock;
        private System.Windows.Forms.TabPage tab_remove;
        private System.Windows.Forms.TextBox textBox_quantity;
        private System.Windows.Forms.Label label_quantity;
        private System.Windows.Forms.TabPage tab_search;
        private System.Windows.Forms.ListBox listBox_remove;
        private System.Windows.Forms.Button button_search;
        private System.Windows.Forms.ComboBox comboBox_cat_srch;
        private System.Windows.Forms.TextBox textBox_col_srch;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button button_remove;
        private System.Windows.Forms.Button button_restock;
        private System.Windows.Forms.ListBox listBox_restock;
        private System.Windows.Forms.TextBox textBox_restock_quantity;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Diagnostics.Process process1;
        private System.Windows.Forms.ListBox listBox_search;
        private System.Windows.Forms.Button button_search_clear;
    }
}

