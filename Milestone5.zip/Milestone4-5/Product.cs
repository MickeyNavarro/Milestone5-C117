﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mileston4_5
{
    public class ClothingItem
    {
        public string Category { set; get; }
        public string Type { set; get; }
        public string Material { set; get; }
        public string Color { set; get; }
        public string Comments { set; get; }
        public string MarkedAs { set; get; }

        //constructor is almost always public 
        public ClothingItem() { }

        public override string ToString()
        {
            return this.Color + " " + this.Type + " " + this.Category + " (" + this.Comments + ")" + " : " + this.MarkedAs;
        }
    }
}
