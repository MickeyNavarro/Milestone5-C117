﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone4_5
{
    public class ClothingItem
    {
        public int ID { set; get; }
        public string Category { set; get; }
        public string Type { set; get; }
        public string Material { set; get; }
        public string Color { set; get; }
        public string Comments { set; get; }
        public string MarkedAs { set; get; }
        public int Quantity { set; get; }

        //constructor is almost always public 
        public ClothingItem() { }

        public override string ToString()
        {
            return this.ID + "\n" + this.Category + "\n" + this.Type + "\n" + this.Material + "\n" +  this.Color + "\n" + this.Quantity + "\n" + this.Comments + "\n" + this.MarkedAs;
        }

        public string ToShorthand()
        {
            return this.Quantity + " " + this.Color + " " + this.Type + " " + this.Category + " (" + this.Comments + ") : " + this.ID;
        }

        public override bool Equals (object obj)
        {
            //provide the rules for equality
            //make sure obj is a ClothingItem
            if (obj is ClothingItem)
            {
                //so cast obj to a ClothingItem
                ClothingItem itm = (ClothingItem)obj;
                //compare category, color, type, and material
                if (itm.Category == this.Category &&
                    itm.Color == this.Color &&
                    itm.Type == this.Type &&
                    itm.Material == this.Material)
                    return true; 
            }
            return false; 
        }
    }
}
