﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Almicke "Mickey" Navarro 
//CST117 
//Date: April 26, 2018
//This is my own work.

namespace Milestone4_5
{
    public partial class ClothesInventory1 : Form
    {
        private InventoryManager im = new InventoryManager();
        private DataTable dt = new DataTable();
        private DataTable categoryTable = new DataTable();

        public ClothesInventory1()
        {
            InitializeComponent();

            //update the color of the dt to match the form font 
            this.dataGridView1.DefaultCellStyle.Font = new Font("Agency FB", 20);

            LoadManager();

            PopulateListBoxes();

            //get data table
            getDataTable();
            this.dataGridView1.DataSource = dt;

            //make a data table for the category 
            this.categoryTable = this.getCategoryTable(); 

            //add the categories in the data table to the combo box on the add tab
            foreach (DataRow dr in categoryTable.Rows)
            {
                this.comboBox_category.Items.Add(dr["Name"].ToString());
            }

            //add the categories in the data table to the combo box on the search tab
            foreach (DataRow dr in categoryTable.Rows)
            {
                this.comboBox_cat_srch.Items.Add(dr["Name"].ToString());
            }
        }

        private void getDataTable()
        {
            //create a new data table 
            dt = new DataTable();

            //fills the data table 

            //Step 1: get the array representation of the inventory manager 
            ClothingItem[] item_array = im.toArray();

            //Step 2: set the columns on the data table 
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("Category", typeof(string));
            dt.Columns.Add("Type", typeof(string));
            dt.Columns.Add("Material", typeof(string));
            dt.Columns.Add("Color", typeof(string));
            dt.Columns.Add("Quantity", typeof(int));
            dt.Columns.Add("Comments", typeof(string));
            dt.Columns.Add("Marked As", typeof(string));

            //Step 3: go through all of the items in the item_array and add row to table for each
            foreach (ClothingItem item in item_array)
            {
                dt.Rows.Add(item.ID, item.Category, item.Type, item.Material, item.Color, item.Quantity, item.Comments, item.MarkedAs);
            }

        }

        private DataTable getCategoryTable()
        {
            //make a datatable 
            DataTable table = new DataTable();

            //add necessary columns 
            table.Columns.Add("Name"); 

            //creates a reader to process the file 
            StreamReader sr = new StreamReader("categoryList.txt");

            string str; 
            while (!sr.EndOfStream)
            {
                //read a line from the file
                str = sr.ReadLine();
                //add it to the table 
                table.Rows.Add(str);
            }

            return table; 
        }

        public void PopulateListBoxes ()
        {
            foreach (ClothingItem itm in this.im.toArray())
            {
                //output using the shorthand method to make it easier to read
                this.listBox_restock.Items.Add(itm.ToShorthand());
            }
            foreach (ClothingItem itm in this.im.toArray())
            {
                this.listBox_remove.Items.Add(itm.ToShorthand());
            }

        }

        private void button_add_Click(object sender, EventArgs e)
        {
            //create product 
            ClothingItem clothes = new ClothingItem();

            try
            {
                clothes.Quantity = int.Parse(textBox_quantity.Text);
                try
                {
                    //get text from name box and update 
                    clothes.ID = im.idCounter; 
                    clothes.Category = this.comboBox_category.SelectedItem.ToString();
                    clothes.Type = this.comboBox_type.SelectedItem.ToString();
                    clothes.Material = textBox_material.Text;
                    clothes.Color = textBox_color.Text;
                    clothes.Comments = textBox_comment.Text;
                    clothes.MarkedAs = this.comboBox_mark.SelectedItem.ToString();

                    //checks if the item is already in the inventory
                    if (!im.addItem(clothes))
                    {
                        //output
                        MessageBox.Show("Oops! This item of clothing already exists in the inventory!\n");
                    }
                    else
                    {
                        //output
                        MessageBox.Show("Success! " + clothes.Quantity + " " + clothes.Color + " " + clothes.Type + " " + clothes.Category + " has been added to the inventory!\n");
                    }
                    //add clothes to list
                    im.addItem(clothes);
                }
                catch
                {
                    MessageBox.Show("Must complete all fields");
                }
            }
            catch
            {
                MessageBox.Show("Must insert a number/digit value for quantity!");
            }

            //update the datatable 
            getDataTable();
            this.dataGridView1.DataSource = this.dt;
            //update the listboxes 
            listBox_remove.Items.Clear();
            listBox_restock.Items.Clear();
            PopulateListBoxes();

        }

        private void button_restock_Click(object sender, EventArgs e)
        {
            //create a char to get the ID number at the end of the string 
            //https://stackoverflow.com/questions/18285566/how-extract-a-specific-character-in-a-string-in-c-sharp-by-index
            char getID = this.listBox_restock.SelectedItem.ToString()[listBox_restock.SelectedItem.ToString().Length - 1];

            //convert the char into an int
            //https://stackoverflow.com/questions/3665757/how-to-convert-char-to-int
            int IDnum = (int)Char.GetNumericValue(getID);

            //try-catch method to make sure the quantity # is an int 
            try
            {
                //get the quantity to add/restock 
                int restockNum = int.Parse(textBox_restock_quantity.Text);

                //check if any ID matches in the inventory
                foreach (ClothingItem itm in im.toArray())
                {
                    //checks if ID does match with an ID # in the inventory & was restocked
                    if (IDnum == itm.ID)
                    {
                        //checks if item has really been restocked 
                        if (im.restockItem(itm, restockNum) == true)
                        {
                            MessageBox.Show("Piece of clothing has been restocked with " + restockNum + " item(s)!");
                        }
                        else
                        {
                            MessageBox.Show("Oops! Item was not restocked!");
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Must insert a number/digit value for quantity!");
            }
            //update the datatable 
            getDataTable();
            this.dataGridView1.DataSource = this.dt;
            //update the listboxes 
            listBox_remove.Items.Clear(); 
            listBox_restock.Items.Clear();
            PopulateListBoxes(); 
        }

        private void button_remove_Click(object sender, EventArgs e)
        {
            //create a char to get the ID number at the end of the string 
            //https://stackoverflow.com/questions/18285566/how-extract-a-specific-character-in-a-string-in-c-sharp-by-index
            char getID = this.listBox_remove.SelectedItem.ToString()[listBox_remove.SelectedItem.ToString().Length - 1];

            //convert the char into an int
            //https://stackoverflow.com/questions/3665757/how-to-convert-char-to-int
            int IDnum = (int)Char.GetNumericValue(getID);

            //check if any ID matches in the inventory
            foreach (ClothingItem itm in im.toArray())
            {
                //checks if ID does match with an ID # in the inventory & was restocked
                if (IDnum == itm.ID)
                {
                    //checks if user wants to delete the item
                    //https://stackoverflow.com/questions/5414270/messagebox-buttons
                    if (MessageBox.Show("Are you sure you want to delete this item?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        if (im.removeItem(itm)==true)
                        {
                            MessageBox.Show("Item has been removed!"); 
                        }
                    }
                    else
                    {
                        MessageBox.Show("Item is stil in your inventory!");
                    }
                }
            }
            //update the datatable 
            getDataTable();
            this.dataGridView1.DataSource = this.dt;
            //update the listboxes 
            listBox_remove.Items.Clear();
            listBox_restock.Items.Clear();
            PopulateListBoxes();
        }

        private void button_search_Click(object sender, EventArgs e)
        {
            //clear the listbox for upcoming search 
            listBox_search.Items.Clear();            

            //checks if the category search combobox does not have text 
            //---if yes, both search criterias, or just the category criteria alone, will be added to the listbox
            if (comboBox_cat_srch.Text != "")
            {
                //get the list of items that meet the search criteria 
                List<ClothingItem> searchCategoryItems = im.searchCategory(comboBox_cat_srch.SelectedItem.ToString());
                List<ClothingItem> searchColorItems = im.searchColor(textBox_col_srch.Text);

                //create a new list 
                List<ClothingItem> searchItems = new List<ClothingItem>();

                //populate searchItems with both the color and category lists
                searchItems.AddRange(searchCategoryItems);
                searchItems.AddRange(searchColorItems);

                //loop over the all search items
                //--make the list distinct, or so that list items would not repeat
                foreach (ClothingItem itm in searchItems.Distinct())
                {
                    listBox_search.Items.Add(itm.ToShorthand());
                }

            }
            //---if no, only the color criteria will be added to the listbox
            else 
            {
                //get the list of items that meet the search criteria 
                List<ClothingItem> searchColorItems = im.searchColor(textBox_col_srch.Text);

                //loop over the search items based on color criteria
                foreach (ClothingItem itm in searchColorItems)
                {
                    listBox_search.Items.Add(itm.ToShorthand());
                }
            }
        }

        private void ClothesInventory1_FormClosing(object sender, FormClosingEventArgs e)
        {
            List<string> fileUpdateLines = new List<string>(); 

            foreach (ClothingItem itm in this.im.toArray())
            {
                fileUpdateLines.Add(itm.ToString());
            }
  
            //write the list to the file 
            File.WriteAllLines("inventory.out", fileUpdateLines);
        }

        private void LoadManager()
        {
            StreamReader sr = new StreamReader("inventory.out");
            im = new InventoryManager();
            ClothingItem itm = new ClothingItem();

            string str; 
            while (!sr.EndOfStream)
            {
                //get id 
                str = sr.ReadLine();
                itm.ID = int.Parse(str); 

                //get category
                str = sr.ReadLine();
                itm.Category = str;

                //get type 
                str = sr.ReadLine();
                itm.Type = str;

                //get material 
                str = sr.ReadLine();
                itm.Material = str;

                //get color 
                str = sr.ReadLine();
                itm.Color = str;

                //get quantity 
                str = sr.ReadLine();
                itm.Quantity = int.Parse(str);

                //get comments 
                str = sr.ReadLine();
                itm.Comments = str;

                //get marked as 
                str = sr.ReadLine();
                itm.MarkedAs = str;

                //add to manager 
                im.addItem(itm);

                //reset the item for iteration 
                itm = new ClothingItem(); 
            }
            sr.Close();
        }

        private void button_search_clear_Click(object sender, EventArgs e)
        {
            //allows the user to manually clear the listbox
            listBox_search.Items.Clear();
        }
    }
}
