﻿using System;
using System.Collections.Generic;
using System.Text;
//make sure to use winForms to be able to use message boxes within the form
using System.Windows.Forms;

//Almicke "Mickey" Navarro 
//CST117 
//Date: April 6, 2018
//This is my own work. 

namespace Milestone4_5
{
    class InventoryManager
    {
        private static List<ClothingItem> myClothes;

        //create public id counter to assign each item to an id # 
        public int idCounter = 1;

        //constructor 
        public InventoryManager()
        {
            myClothes = new List<ClothingItem>();
            /*
            //test item #1
            ClothingItem item1 = new ClothingItem();
            item1.Category = "Shirt";
            item1.Type = "School";
            item1.Material = "Cotton";
            item1.Color = "Red";
            item1.Comments = "Test item 1";
            item1.MarkedAs = "Keep";
            item1.Quantity = 2;
            //add item above for testing
            myClothes.Add(item1);

            //test item #2
            ClothingItem item2 = new ClothingItem();
            item2.Category = "Pants";
            item2.Type = "Casual";
            item2.Material = "Jeans";
            item2.Color = "Blue";
            item2.Comments = "Test item 2";
            item2.MarkedAs = "Sell";
            item2.Quantity = 5;
            myClothes.Add(item2);
            */
        }

        public bool addItem(ClothingItem item)
        {
            //checks if the item already exists inside the inventory
            if (myClothes.Contains(item))
            {
                //returns that the item has not been added
                return false;
            }
            else
            {
                //adds the item to the inventory 
                myClothes.Add(item);
                //increase the id count 
                idCounter++;
                //returns that the item has been added 
                return true; 
            }

        }

        public bool restockItem(ClothingItem item, int newStock)
        {
            //checks if item exists within the inventory
            if (myClothes.Contains(item))
            {
                //restocks the item with the given amount 
                item.Quantity += newStock;
                //returns true, or that the item has been restocked
                return true;
            }
            else
            {
                //returns false, or that the item has not been restocked
                return false;
            }
        }

        public bool removeItem(ClothingItem item)
        {
            //checks if item exists within the inventory
            if (myClothes.Contains(item))
            {
                //removes the item
                myClothes.Remove(item);
                //returns true, or that the item has been removed
                return true;
            }
            else
            {
                //returns false, or that the item has not been removed
                return false;
            }
        }

        public void displayItems()
        {
            Console.WriteLine("Inventory of my clothes: ");
            for (int i = 0; i < myClothes.Count; i++)
            {
                //outputs the inventory of clothes
                Console.WriteLine(myClothes[i]);
            }

        }

        public List<ClothingItem> searchCategory(String Category)
        {
            //create a new list of clothing items to collect the results
            List<ClothingItem> results = new List<ClothingItem>();
            //checks each item within the inventory 
            foreach (ClothingItem i in myClothes)
            {
                //checks those items if they match the given category
                if (i.Category == Category)
                {
                    //adds those items with the same given category to the list of results
                    results.Add(i);
                }
            }
            //outputs the search results 
            return results;
        }

        public List<ClothingItem> searchColor(String Color)
        {
            //create a new list of clothing items to collect the results
            List<ClothingItem> results = new List<ClothingItem>();
            //checks each item within the inventory 
            foreach (ClothingItem i in myClothes)
            {
                //checks those items if they match the given color
                if (i.Color == Color)
                {
                    //adds those items with the same given color to the list of results
                    results.Add(i);
                }
            }
            //outputs the search results 
            return results;
        }

        //toArray method that returns the items in the array 
        public ClothingItem[] toArray()
        {
            //create an array of the appropriate size
            ClothingItem[] arr = new ClothingItem[myClothes.Count];

            //copy the items from my list into this array 
            int i = 0;
            foreach (ClothingItem item in myClothes)
            {
                //since "++" is on the right side, it will be a post increment so it will start at 0 then add every time there is a new item 
                arr[i++] = item;
            }
            return arr; 
        }
    }
}